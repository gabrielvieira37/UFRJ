# IA_Othello
Repositório com os códigos do Othello, feitos para a disciplina de Inteligência Artificial 2017.1
